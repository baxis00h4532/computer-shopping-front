let loggedIn = localStorage.getItem("logged-in");
let loggedInUsername = localStorage.getItem("logged-in-username");


let phonesButton = document.getElementById("phonesButton");
let salesButton = document.getElementById("salesButton");
let ordersButton = document.getElementById("ordersButton");
let loginButton = document.getElementById("loginButton");
let logoutButton = document.getElementById("logoutButton");
let resetButton = document.getElementById("resetButton");

function changeToPhonePage(){
   window.location.href = 'phones.html';
}

function changeToOrdersPage(){
  window.location.href  = "orders.html";
}

function changeToSalesPage(){
  window.location.href = 'sales.html';
}
function changeToLoginPage(){
  window.location.href = 'login.html';
}

function checkLogin(){
  if(loggedIn=='true'){
    loginButton.style.display = 'none';
    document.getElementById("index-user").innerText = loggedInUsername;
  }else{
    document.getElementById("index-user").innerText = "Daxil olunmayıb";
    ordersButton.style.display = "none";
    loginButton.style.display = 'inline-block';
    phonesButton.style.display = 'none';
    logoutButton.style.display = 'none';
  }
}
function logOut(){
     localStorage.setItem("logged-in",false);
     window.location.reload();
}

function resetAllData(){
   let text = "Məlumatlar silinəcək,əməliyyata davam etmək istəyirsinizmi?"
   if(confirm(text)==true){
     localStorage.clear();
     window.location.reload();
   }
}
checkLogin();