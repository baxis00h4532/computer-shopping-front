let localStorageString = localStorage.getItem("sellers");
let sellers = [];

if(localStorageString == null){
    sellers  = [];
}else{
    sellers = JSON.parse(localStorageString);
}


function changeToCreateAccountPage(){
    window.location.href = 'create-account.html';
}
function loginSeller(event){
    event.preventDefault();
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    for(let i=0;i<sellers.length;i++){

        if(username=="admin"&&password=="admin"){
            window.location.href = "admin.html";
        }else{
        if(username == sellers[i].username && password == sellers[i].password){
            document.getElementById("login-success").style.display = 'block';
            localStorage.setItem("logged-in",true);
            localStorage.setItem("logged-in-username",username);
            setTimeout(()=>{
                document.getElementById("login-success").style.display = 'none';
                window.location.href = 'index.html';
            },1500);
            break;
            
        }else if(i==sellers.length-1){
            document.getElementById("login-error").style.display = 'block';

            document.getElementById("password").value = "";

            setTimeout(()=>{
                document.getElementById("login-error").style.display = 'none';
            },1500)
        }
    }
        

    }
}
