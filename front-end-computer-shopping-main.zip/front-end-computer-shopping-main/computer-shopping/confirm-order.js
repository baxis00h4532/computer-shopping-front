let basketDetailsString = localStorage.getItem("basket-details");
let ordersString = localStorage.getItem("orders");

let basketDetails = [];
let orders = [];

if(basketDetailsString == null){
   basketDetails = [];
}else{
   basketDetails = JSON.parse(basketDetailsString);
}

if(ordersString == null){
    orders = [];
}else{
    orders = JSON.parse(ordersString);
}



function confirmOrder(event){
    event.preventDefault();

    let name = document.getElementById("name").value;
    let surname = document.getElementById("surname").value;
    let phone = document.getElementById("phone").value;
    let email = document.getElementById("email").value;
    let address = document.getElementById("address").value;
    let note = document.getElementById("note").value;

    let customer = {};
    customer.name = name;
    customer.surname = surname;
    customer.phone = phone;
    customer.email = email;
    customer.address = address;
    customer.note = note;

    let order = {};
    order.id = orders.length;
    let currentDate = new Date();
    order.date = currentDate;
    order.customer = customer;
    order.details  = basketDetails;
  
    orders.push(order);
    localStorage.setItem("orders",JSON.stringify(orders));
    localStorage.removeItem("basket-phones");
    localStorage.removeItem("basket-details");
    document.getElementById("ordersuccess").style.display = "block";
    setTimeout(()=>{
        window.location.href = "index.html";
    },1000);
    
    
}