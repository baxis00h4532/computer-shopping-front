let categoriesString = localStorage.getItem("categories");

let categories = [];

if(categoriesString == null){
    categories = [];
}else{
    categories = JSON.parse(categoriesString);
}

function changeToIndexPage(){
    window.location.href = "index.html";
}

function toggleCategory(event){
    event.preventDefault();

    let toggleButton = document.getElementById("togglebutton");
    

    let category = document.getElementById("category");

    if(toggleButton.innerText == "Redaktə et"){
       for(let i=0;i<categories.length;i++){
         if(categories[i]==document.getElementById("currentelement").innerText){
            categories[i] = category.value;
         }  
       }   
    }else{
        categories.push(category.value);
    }
    localStorage.setItem("categories",JSON.stringify(categories));
    window.location.reload();
}

function loadCategories(){
    let list = document.getElementById("categorylist");
    list.innerHTML = "";

    for(let i=0;i<categories.length;i++){
        let li = document.createElement("li");
        li.setAttribute("class","list-group-item");
        li.setAttribute("onclick","specialListItem(this,'"+categories[i]+"');");
        li.innerText = categories[i];
        list.appendChild(li);
        
    }
}


function specialListItem(element,category){
    let list = document.getElementById("categorylist");
    
    for(let i=0;i<list.children.length;i++){
        let item = list.children[i];
        item.removeAttribute("style");
        item.removeAttribute("id");
    }

    element.style.color = "blue";
    element.style.fontSize = "18px";
    element.style.fontWeight = "bold";
    element.id = "currentelement";

    let buttons = document.getElementById("addedbuttons");
    buttons.style.display = "inline-block";
    buttons.innerHTML = "";

    let input = document.getElementById("category");

    input.value = category;

    let toggleButton = document.getElementById("togglebutton");

    toggleButton.innerText = "Redaktə et";  

    let deleteButton = document.createElement("button");
    deleteButton.innerText = "Sil";
    deleteButton.setAttribute("type","button");
    deleteButton.setAttribute("class","btn btn-danger");
    deleteButton.setAttribute("onclick","deleteCategory('"+category+"');");

    buttons.appendChild(deleteButton);
}

function deleteCategory(name){

    for(let z=0;z<categories.length;z++){
        if(categories[z]==name){
            categories.splice(z,1);
            break;
        }
    }
    localStorage.setItem("categories",JSON.stringify(categories));
    document.getElementById("category").value = "";
    window.location.reload();

}
loadCategories();