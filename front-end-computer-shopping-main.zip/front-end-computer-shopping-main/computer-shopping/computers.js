let localStorageString = localStorage.getItem("phones");
let categoriesString = localStorage.getItem("categories");
let localStorageUsername = localStorage.getItem("logged-in-username");
let phones = [];
let categories = [];

let currentPhoneId = document.getElementById("editphoneid");
if(localStorageString ==  null){
    phones = [];
}else{
    phones =  JSON.parse(localStorageString);
}
if(categoriesString ==  null){
    categories = [];
}else{
    categories = JSON.parse(categoriesString);
}

function changeToIndexPage(){
    window.location.href = 'index.html';
}

function insertCategories(){
    let category = document.getElementById("category");
    let editCategory = document.getElementById("editcategory");

    for(let i=0;i<categories.length;i++){
        let option = "<option value='"+categories[i]+"'>"+categories[i]+"</option>";
        category.innerHTML += option;
        editCategory.innerHTML += option;
    }
}

function addPhone(event){
    event.preventDefault();

    let id = phones.length;
    let name = document.getElementById("name").value;
    let category = document.getElementById("category").value;
    let price = document.getElementById("price").value;
    let description = document.getElementById("description").value;
    let isnew = document.getElementById("isnew").value;
    let image = document.getElementById("image").value;
    let ram  = document.getElementById("ram").value;
    let rom = document.getElementById("rom").value;

    const phone = {};
   
    phone.username = localStorageUsername;
    phone.id = id;
    phone.name = name;
    phone.category = category;
    phone.price = price;
    phone.description = description;
    phone.isnew = isnew;
    phone.image = image;
    phone.ram = ram;
    phone.rom = rom;

    phones.push(phone);
    

    localStorage.setItem("phones",JSON.stringify(phones));
    document.getElementById("loadingspinner").style.display = 'inline-block';
    document.getElementById('addphone-success').style.display = 'block';
    setTimeout(()=>{
        document.getElementById("loadingspinner").style.display = 'none';
        window.location.reload();
    },500);
}

function inputImage(url,id){
    document.getElementById(id+"view").style.display = 'block';
    document.getElementById(id+"view").src = url;

}

function editPhoneValues(id){
    
    let phone = phones[id];

    currentPhoneId.innerText = id;

    let name = document.getElementById("editname");
    let category = document.getElementById("editcategory");
    let price = document.getElementById("editprice");
    let description = document.getElementById("editdescription");
    let isnew = document.getElementById("editisnew");
    let image = document.getElementById("editimage");
    let ram  = document.getElementById("editram");
    let rom = document.getElementById("editrom");

    name.value = phone.name;
    category.value = phone.category;
    price.value = phone.price;
    description.value = phone.description;
    isnew.value = phone.isNew;
    image.value = phone.image;
    ram.value   = phone.ram;
    rom.value   = phone.rom; 
}

function editPhone(event){
    event.preventDefault();

    let id = currentPhoneId.innerText;

    let name = document.getElementById("editname").value;
    let category = document.getElementById("editcategory").value;
    let price = document.getElementById("editprice").value;
    let description = document.getElementById("editdescription").value;
    let isnew = document.getElementById("editisnew").value;
    let image = document.getElementById("editimage").value;
    let ram  = document.getElementById("editram").value;
    let rom = document.getElementById("editrom").value;

    phones[id].name = name;
    phones[id].category = category;
    phones[id].price = price;
    phones[id].description = description;
    phones[id].isnew = isnew;
    phones[id].image = image;
    phones[id].ram = ram;
    phones[id].rom = rom;

    localStorage.setItem("phones",JSON.stringify(phones));
    window.location.reload();
}

function deletePhone(id){
    for(let i=0;i<phones.length;i++){
        let phoneId = phones[i].id;
        if(id==phoneId){
            phones.splice(i,1);
            break;
        }
    }
    localStorage.setItem("phones",JSON.stringify(phones));
    window.location.reload();
    
}


function loadPhones(){
    let table = document.getElementById("customtablecontent");
    for(let i=0;i<phones.length;i++){
        let phone = phones[i];
        
        if(localStorageUsername == phone.username){
            let id = phone.id;
            let name = phone.name;
            let image = phone.image;
            let price = phone.price;
    
            let tr = document.createElement("tr");
            let idTd = document.createElement("td");
            let nameTd = document.createElement("td");
            let imageTd = document.createElement("td"); 
            let priceTd = document.createElement("td");
            let actionTd = document.createElement("td");
            
            
    
            idTd.innerText = id;
            nameTd.innerText = name;
            let imageElement = document.createElement("img");
            imageElement.style.width = '140px';
            imageElement.style.height = '140px';
            imageElement.src = image;
            imageElement.setAttribute("data-bs-toggle","modal");
            imageElement.setAttribute("data-bs-target","#imagemodal");
            imageElement.setAttribute("onclick","document.getElementById('imagemodalsource').src = '"+image+"'");
            
            imageTd.appendChild(imageElement);
            priceTd.innerText = price;
    
            let deleteButton = document.createElement("button");
            deleteButton.innerText = 'Sil';
            deleteButton.setAttribute("class",'btn btn-danger');
            deleteButton.style.marginRight = '1%';
            deleteButton.setAttribute("onclick","deletePhone("+id+")");
            actionTd.appendChild(deleteButton);
    
            let editButton = document.createElement("button");
            editButton.innerText = 'Redaktə';
            editButton.setAttribute("class",'btn btn-primary');
            editButton.setAttribute("data-bs-toggle",'modal');
            editButton.setAttribute("data-bs-target",'#modal2');
            editButton.setAttribute("onclick","editPhoneValues("+id+")");
            actionTd.appendChild(editButton);
    
            tr.appendChild(idTd);
            tr.appendChild(nameTd);
            tr.appendChild(imageTd);
            tr.appendChild(priceTd);
            tr.appendChild(actionTd);
    
            
    
            table.appendChild(tr);
        }

    }
}
loadPhones();
insertCategories();