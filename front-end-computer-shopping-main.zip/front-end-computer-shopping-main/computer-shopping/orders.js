let ordersString = localStorage.getItem("orders");
let sellerUsername = localStorage.getItem("logged-in-username");

let orders = [];

if(ordersString == null){
    orders = [];
}else{
    orders = JSON.parse(ordersString);
}

function changeToIndexPage(){
    window.location.href = "index.html";
}

function loadOrders(){
    let table  = document.getElementById("orderstablecontent");

    for(let i=0;i<orders.length;i++){
        let notSellerOrder = true;
        let order = orders[i];
        let id = order.id;
        let date = new Date(order.date);
        let customer = order.customer;
        let detailsArray = order.details;
      
        let totalPrice = 0;
        let note = customer.note;

        let tr = document.createElement("tr");

        let idTd = document.createElement("td");
        let dateTd = document.createElement("td");
        let customerTd = document.createElement("td");
        let orderTd = document.createElement("td");
        let totalPriceTd = document.createElement("td");
        totalPriceTd.style.color = "red";
        let noteTd = document.createElement("td");

        idTd.innerText = id;
        dateTd.innerText = date.toLocaleDateString();
        customerTd.innerHTML = "<ul> <li>Ad: "+customer.name+"</li> <li>Ünvan: "+customer.address+"</li> <li>Telefon: "+customer.phone+"</li> <li>Email: "+customer.email+"</li> </ul>";
        orderTd.innerHTML += "<ol>";

        for(let j=0;j<detailsArray.length;j++){
          let item = detailsArray[j];
          if(item.phone.username == sellerUsername){
             notSellerOrder = false;
          }else{
            continue;
          }
          totalPrice += Number(item.phone.price)*Number(item.quantity);
          orderTd.innerHTML += "<li> "+item.phone.category+" "+item.phone.name+" <ul> <li>Qiyməti: "+item.phone.price+"</li> <li>Miqdarı: "+item.quantity+"</li> <li>Ümumi qiymət: "+item.finalPrice+"</li>  </ul> </li>";
        }
        if(notSellerOrder==true){
            break;
        }
        orderTd.innerHTML += "</ol>";

        totalPriceTd.innerText = totalPrice + " AZN";
        noteTd.innerText = note;

        tr.appendChild(idTd);
        tr.appendChild(dateTd);
        tr.appendChild(customerTd);
        tr.appendChild(orderTd);
        tr.appendChild(totalPriceTd);
        tr.appendChild(noteTd);

        table.appendChild(tr);
    }
}
loadOrders();