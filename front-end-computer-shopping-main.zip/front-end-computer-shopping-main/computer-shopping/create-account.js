let localStorageString = localStorage.getItem("sellers");
let sellers = [];

if(localStorageString == null){
  sellers = [];
}else{
  sellers = JSON.parse(localStorageString);
}

let idCount = localStorage.getItem("seller-id");
if(idCount == null){
   idCount = 0;
}
function createSeller(event){
    event.preventDefault();
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    const seller = {};
    seller.id = idCount;
    seller.username = username;
    seller.password = password;

    sellers.push(seller);

    localStorage.setItem("sellers",JSON.stringify(sellers));
    idCount++;
    localStorage.setItem("seller-id",idCount);

    document.getElementById("register-success").style.display = 'block';

    setTimeout(()=>{
      window.location.href = 'login.html';
    }, 1500);
}

function changeToLoginPage(){
    window.location.href = "login.html";
}