let categoriesString = localStorage.getItem("categories");
let phonesString = localStorage.getItem("phones");
let basketString = localStorage.getItem("basket-phones");
let basketDetailsString = localStorage.getItem("basket-details");


let categories = [];
let phones = [];
let basket = [];
let basketDetails = [];

let searchString = "";

let searchCategoryString = "";


if(categoriesString == null){
    categories = [];
}else{
    categories = JSON.parse(categoriesString);
}

if(phonesString == null){
    phones = [];
}else{
    phones = JSON.parse(phonesString);
}

if(basketString == null){
   basket = [];
}else{
   basket = JSON.parse(basketString);
}

if(basketDetailsString == null){
    basketDetails = [];
 }else{
    basketDetails = JSON.parse(basketDetailsString);
 }

 function countBasketLength(){
    document.getElementById("basketlength").innerText = basket.length;
 } 


function changeToIndexPage(){
    window.location.href = 'index.html';
}


function loadCategories(){
    let list = document.getElementById("categories");

    list.innerHTML = "";

    for(let i=0;i<categories.length;i++){
        if(searchCategoryString == ""){
        let li = document.createElement("li");
        li.innerText = categories[i];
        li.setAttribute("class","list-group-item");
        li.setAttribute("onclick","clickedCategory(this,this.innerText);");
        list.appendChild(li);
        }else if(categories[i].toLowerCase().indexOf(searchCategoryString.toLowerCase())>-1){
        let li = document.createElement("li");
        li.innerText = categories[i];
        li.setAttribute("class","list-group-item");
        li.setAttribute("onclick","clickedCategory(this,this.innerText);");
        list.appendChild(li);
        }
    }
}

function clickedCategory(element,category){
    
    

    let oldElement = document.getElementById("oldelement");
    if(oldElement!=null){
    oldElement.removeAttribute("id");
    oldElement.removeAttribute("style"); 
    }
    if(oldElement!=element){
    element.id = "oldelement";
    element.style.color = "blue";
    element.style.fontSize = "18px";
    element.style.fontWeight = "bold";
    searchString = category;
    }else{
       element.removeAttribute("style");
       element.removeAttribute("id");
       searchString = ""; 
    }
    loadSalePhones();
}

function search(text){
    searchString = text;
    loadSalePhones();
}

function searchCategory(text){
    searchCategoryString = text;
    loadCategories();
}


function addToBasket(phone){
   let id = phone.id;
   let phoneExists = false;
   for(let i=0;i<basket.length;i++){
      if(basket[i].id == id){
         phoneExists = true;
         document.getElementById("phonealreadyexists").style.display = 'block';
         setTimeout(()=>{
            document.getElementById("phonealreadyexists").style.display = 'none';
         },1100)
         break;
      }
   }
   if(phoneExists==false){
    basket.push(phone);
    localStorage.setItem("basket-phones",JSON.stringify(basket));
   }
   countBasketLength();
}

function clearBasket(){
    basket = [];
    localStorage.removeItem("basket-phones");
    loadBasket();
}

function loadBasket(){
   let basketTableContent = document.getElementById("baskettablecontent");

   basketTableContent.innerHTML = '';

   for(let i=0;i<basket.length;i++){

      let phone = basket[i];

      let tr = document.createElement("tr");

      let idTd = document.createElement("td");
      let imageTd = document.createElement("td");
      let nameTd = document.createElement("td");
      let priceTd = document.createElement("td");
      let quantityTd = document.createElement("td");
      let finalPriceTd = document.createElement("td");
      let actionTd = document.createElement("td");



      idTd.innerText = phone.id;
      let image = document.createElement("img");
      image.src = phone.image;
      image.style.width = '100px';
      image.style.height = '100px';
      imageTd.appendChild(image);
      nameTd.innerText = phone.category + phone.name;
      priceTd.innerText = phone.price;
      
      let quantityInput = document.createElement("input");
      quantityInput.type = "number";
      quantityInput.min = '0';
      quantityInput.setAttribute("oninput","calculatePrice("+phone.id+",this.value,"+phone.price+");");
      quantityInput.setAttribute("required","on");
      quantityInput.setAttribute("min","0");
      quantityTd.appendChild(quantityInput);
      finalPriceTd.id = "price"+phone.id;
      finalPriceTd.innerText = 0;

      let deleteButton = document.createElement("button");
      deleteButton.innerText = "x";
      deleteButton.setAttribute("class","btn btn-danger");
      deleteButton.setAttribute("onclick","deletePhoneFromBasket("+phone.id+");");
      actionTd.appendChild(deleteButton);

      
      tr.appendChild(idTd);
      tr.appendChild(imageTd);
      tr.appendChild(nameTd);
      tr.appendChild(priceTd);
      tr.appendChild(quantityTd);
      tr.appendChild(finalPriceTd);
      tr.appendChild(actionTd);

      basketTableContent.appendChild(tr);

      document.getElementById("totalprice").innerText = 0;

      
      
   }
}

function deletePhoneFromBasket(id){

    for(let i=0;i<basket.length;i++){
        if(basket[i].id == id){
            basket.splice(i,1);
            localStorage.setItem("basket-phones",JSON.stringify(basket));
            loadBasket();
            calculateTotalPrice();
        }
    }
  countBasketLength();
}

function calculatePrice(id,quantity,price){
    document.getElementById("price"+id).innerText = quantity * price;
    calculateTotalPrice();
}

function calculateTotalPrice(){
    let sum = 0;
    for(let i=0;i<basket.length;i++){
        let id = basket[i].id;
        sum += Number(document.getElementById("price"+id).innerText);
    }
    document.getElementById("totalprice").innerText = sum;
}

function changeToOrderConfirmPage(event){
    event.preventDefault();
    if(basket.length!=0){

       for(let i=0;i<basket.length;i++){
        let phone = basket[i];
        let finalPrice = document.getElementById("price"+phone.id).innerText;

        let basketItem = {};
        basketItem.phone = phone;
        basketItem.quantity = finalPrice / phone.price;
        basketItem.finalPrice = finalPrice;

        basketDetails.push(basketItem);
        localStorage.setItem("basket-details",JSON.stringify(basketDetails));
        window.location.href = "confirm-order.html";
       }
       
    }else{
        alert("Səbət boşdur.");
    }


}



function loadSalePhones(){

    let phonesDiv = document.getElementById("phones");
    phonesDiv.innerHTML = "";
    for(let i=0;i<phones.length;i++){

        let phone = phones[i];
        if(searchString==""){

        
        let colDiv = document.createElement("div");
        colDiv.setAttribute("class","col-sm-3 my-2");
        let div = document.createElement("div");
        div.setAttribute("class","card");

        let phoneImage = document.createElement("img");

        phoneImage.src = phone.image;

        phoneImage.style.width = "55%";
        phoneImage.style.marginInline = "auto";
        phoneImage.style.height = "100px";
        phoneImage.setAttribute("data-bs-toggle","modal");
            phoneImage.setAttribute("data-bs-target","#imagemodal");
            phoneImage.setAttribute("onclick","document.getElementById('imagemodalsource').src = '"+phone.image+"'");

         let divBody = document.createElement("div");
         divBody.setAttribute("class","card-body");
         divBody.innerHTML = "Ad: "+phone.category+" "+phone.name+" <br> Təsvir: "+phone.description+" <br>  Yeni telefon: "+phone.isnew+" <br> Qiymət: "+phone.price+"<br> Nömrə: +994554443322<br> <button onclick='addToBasket("+JSON.stringify(phone)+");' class='btn btn-primary mx-4 mt-1'>Səbətə at</button> ";

        div.appendChild(phoneImage);
        div.appendChild(divBody);
        colDiv.appendChild(div);

        phonesDiv.appendChild(colDiv);
       }else{
          if(phone.category.toLowerCase().indexOf(searchString.toLowerCase())>-1 || phone.name.toLowerCase().indexOf(searchString.toLowerCase())>-1){
            let colDiv = document.createElement("div");
            colDiv.setAttribute("class","col-sm-3 my-2");
            let div = document.createElement("div");
            div.setAttribute("class","card");
    
            let phoneImage = document.createElement("img");
    
            phoneImage.src = phone.image;
    
            phoneImage.style.width = "55%";
            phoneImage.style.marginInline = "auto";
            phoneImage.style.height = "100px";
            phoneImage.setAttribute("data-bs-toggle","modal");
                phoneImage.setAttribute("data-bs-target","#imagemodal");
                phoneImage.setAttribute("onclick","document.getElementById('imagemodalsource').src = '"+phone.image+"'");
    
             let divBody = document.createElement("div");
             divBody.setAttribute("class","card-body");
             divBody.innerHTML = "Ad: "+phone.category+" "+phone.name+" <br> Təsvir: "+phone.description+" <br>  Yeni telefon: "+phone.isnew+" <br> Qiymət: "+phone.price+"<br> Nömrə: +994554443322<br> <button onclick='addToBasket("+JSON.stringify(phone)+");' class='btn btn-primary mx-4 mt-1'>Səbətə at</button> ";
    
            div.appendChild(phoneImage);
            div.appendChild(divBody);
            colDiv.appendChild(div);
    
            phonesDiv.appendChild(colDiv);
          }
       }
    }

}

loadCategories();

loadSalePhones();
countBasketLength();